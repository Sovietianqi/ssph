```{include} ../CREDITS.md
:relative-docs: docs/
:relative-images:
```
