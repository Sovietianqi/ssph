#pragma once

class IPXAddressClass
{
	unsigned char NetworkNumber[4];
	unsigned char NodeAddress[6];
};
